DOMAIN AUDIT HOPPER
Coopa Blue Health world, Round 8 file system.

------------------------------------------------------------------------
FOLDER PREFIXES
------------------------------------------------------------------------

NONE/   One session per .txt file. Paste the prompt. Attach nothing.
        20 sessions per model.

IND_    One session per FILE. Paste the _PROMPT_ file, attach ONE artifact.
        Repeat for each artifact in the folder.
        IND_File_Audit holds 8 artifacts = 8 sessions per model.

ALL_    One session per FOLDER. Paste the _PROMPT_ file, attach EVERY artifact
        in that folder together. 1 session per folder per model.
        3 folders = 3 sessions per model.

Total per model: 20 + 8 + 3 = 31 sessions. Both models: 62.

The _PROMPT_ file is never attached. Paste its contents as the message.

------------------------------------------------------------------------
RESPONSE FILE NAMING
------------------------------------------------------------------------

Save every reply as a plain .txt using DOUBLE underscore as the field
separator. Single underscores appear inside folder names, so double
underscore is what makes this parseable.

  <SOURCE>__<ITEM>__<MODEL>.txt

  SOURCE  the folder name, exactly as written
  ITEM    the prompt ID, artifact number, or the literal word SET
  MODEL   M1, M2, M3

Examples:

  NONE__P02_rad-tech-licensing-agency__M1.txt
  NONE__P02_rad-tech-licensing-agency__M2.txt
  IND_File_Audit__A13__M1.txt
  IND_File_Audit__A20__M2.txt
  ALL_NonPhysician_Population__SET__M1.txt

Keep replies verbatim. Do not summarize, merge two models into one file, or
strip the sections. If a model refuses or returns nothing usable, still create
the file and write REFUSED or EMPTY as the only line, so the gap is visible.

Optional but useful: paste these four lines at the top of each response file.

  SOURCE: <folder>
  ITEM: <P## / A## / SET>
  MODEL: <M1|M2|M3>
  RUN_DATE: <MM/DD/YYYY>

------------------------------------------------------------------------
SUGGESTED ORDER
------------------------------------------------------------------------

1. NONE/ first, all 20, both models. These are pure fact rulings and they
   settle the questions everything else depends on. If P01 comes back
   confirming the two-year physician cycle, that closes the single most
   repeated finding from the first review.

2. ALL_ next, 3 folders. These need the cross-file view and they carry the
   three structural questions.

3. IND_ last, 8 files. Most likely to repeat what the first two passes
   already established, so run it knowing what you already have.

Order within a group does not matter. Every session is independent.

------------------------------------------------------------------------
WHAT EACH PROMPT IS BUILT TO PREVENT
------------------------------------------------------------------------

Every prompt bars authenticity commentary, formatting and document-control
observations, missing-content findings, and role-ownership opinions that are
not tied to a citable rule. Those four categories were most of the volume in
the first review and almost none of its value.

Every prompt requires a named authority with a section number, and sends
anything uncitable to a separate low-priority section instead of letting it
appear as a finding.

Every prompt demands a CONFIRMED CORRECT section of comparable length. The
first review gave almost no confirmations, which is why a correct rule was
nearly "fixed" into a wrong one.

Every prompt states the material is fictional and that some inconsistencies
are deliberate, without saying which. That keeps the models off the traps
without telling them where the traps are.
