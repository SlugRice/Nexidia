# Document Control Convention

Supplementary Reference A48
Prepared by: Coopa Blue Health, Inc., Governance
Classification: INTERNAL — CONFIDENTIAL

This reference sets out the naming, numbering, and revision-marking conventions applied to controlled documents produced by or on behalf of Coopa Blue Health, Inc. It is a quick-reference companion to the definitive Style Guide (A50 — Letterhead & Formatting Standard). Where the two differ in any particular, A50 governs.

The conventions below apply to every controlled document authored under the Coopa Blue Health letterhead after 03/03/2025, regardless of whether the document originates from a hospital function, a corporate function, or a subsidiary operating under Coopa Blue oversight. Pre-acquisition Winston Imaging source material is subject to the exception described at the end of this reference.

---

## Control Number Format

Every controlled document is assigned a control number in the pattern:

    XXX-YYYY-###

The three positional elements are as follows.

**XXX — Owning Function Code.** A three- or four-letter mnemonic identifying the function that owns the document, is accountable for its content, and is the point of contact for revision. The approved function codes are:

| Code  | Owning Function                     |
| ----- | ----------------------------------- |
| CRE   | Credentialing                       |
| GOV   | Governance                          |
| COM   | Compliance                          |
| MED   | Medical Staff                       |
| HR    | Human Resources                     |
| FIN   | Finance                             |
| INT   | Integration                         |
| STR   | Strategy                            |
| CTR   | Contracts                           |
| PE    | Payer Enrollment                    |
| SCH   | Scheduling                          |
| BMDS  | Billing Master Data System          |

Function codes are not combined. A document that touches more than one function is assigned to the function accountable for its content, not the function of its intended audience. Where accountability is genuinely shared, Governance is the tie-breaker and issues the number under the GOV prefix.

**YYYY — Year of First Issue.** The four-digit calendar year in which the document was first issued in its current identity. The year in the control number does not change on revision; a document first issued in 2022 and materially revised in 2026 retains its 2022 control-number year and reflects the update through its revision date (see below). A wholesale re-issue under a new identity — for example, when a policy is superseded rather than revised — takes a new control number under the year of re-issue.

**### — Sequence Number.** A three-digit zero-padded serial, unique within the owning function and year, assigned in order of issuance by the function's document control point. Sequence numbers are not re-used within the same function and year, even if a document is later withdrawn; the withdrawn number is retired and the next document takes the next available serial.

Worked examples:

- `CRE-2026-014` — the fourteenth Credentialing document first issued in 2026.
- `GOV-2022-050` — the fiftieth Governance document first issued in 2022 (this reference's companion Style Guide, A50).
- `INT-2025-008` — the eighth Integration document first issued in 2025.
- `BMDS-CR-2026-041` — a Billing Master Data System change request; note that operational change-request identifiers within the BMDS function may carry an additional intra-function type marker (`-CR-`) between the function code and the year without violating this convention.

---

## Revision Date Format

The most recent substantive revision to a controlled document is marked in the pattern:

    Rev. MM/YYYY

The two-digit month and four-digit year identify the calendar month in which the revision was approved and reissued. Only substantive revisions — those that change content, obligations, references, or effective dates — advance the revision date. Typographical corrections and non-substantive formatting adjustments do not.

The revision date is independent of the year in the control number. A document with control number `CRE-2019-002` and revision date `Rev. 03/2026` was first issued in 2019 and most recently substantively revised in March 2026; both facts are visible on the footer of every page.

Where a document has never been revised since first issue, the revision date matches the month and year of first issue.

---

## Footer Pattern

Every controlled document carries the following footer on every page:

    INTERNAL — CONFIDENTIAL | Control No. XXX-YYYY-### | Rev. MM/YYYY | Page X of Y

The four elements appear in the order shown, separated by pipe characters with single spaces on either side. The classification `INTERNAL — CONFIDENTIAL` is the default and applies unless the document is explicitly classified Public or Restricted by its owning function (see A50, Classification Default).

The `Page X of Y` element uses total-page counting: `Page 3 of 8`, not `Page 3`. Documents produced as controlled excerpts (for example, a policy section circulated on its own) carry the excerpt's own page count in `Y`, not the parent document's.

Worked example, drawn from a Credentialing policy excerpt:

    INTERNAL — CONFIDENTIAL | Control No. CRE-2026-014 | Rev. 03/2026 | Page 3 of 8

Non-controlled documents — routine correspondence, working notes, meeting handouts not intended for retention — do not carry the footer and are not assigned control numbers. The absence of a footer is itself a signal that a document is not part of the controlled set.

---

## Winston Legacy Exception

Documents authored by Winston Imaging before the 03/03/2025 equity-acquisition close retain their original Winston legacy control-number format and typography without alteration. The Winston convention is:

    WI-<TYPE> / rev MM.DD.YYYY

where `<TYPE>` is Winston's own short document-type tag (for example, `WI-SYSDIR` for the Winston Imaging Systems Directory) and the revision date is expressed in Winston's period-separated MM.DD.YYYY form rather than Coopa Blue's slash-separated Rev. MM/YYYY form.

This exception exists to preserve the archival integrity of pre-acquisition source material. A Winston-authored artifact is a historical record of the state of Winston Imaging at a given pre-close date; re-stamping it in Coopa Blue house style would misrepresent its provenance and undermine its evidentiary value in post-acquisition reconciliation work.

The Winston Legacy Exception applies only to the body of pre-close Winston artifacts. Any post-close addendum, correction, or reissue attached to such an artifact — for example, a correction addendum entered by Coopa Blue IT into a legacy Winston systems directory — is stamped in Coopa Blue house style with a Coopa Blue control number and Rev. MM/YYYY revision date. The distinction between the archival body and the post-close addendum is intentional and must be visually preserved.

The exception does not apply to any document authored by Coopa Blue after the 03/03/2025 close, even where the subject matter is Winston-related. Integration plans, IT audits, master-data change requests, and other Coopa Blue-authored artifacts that concern Winston use the Coopa Blue convention (typically under the `INT`, `BMDS`, or `CTR` function codes) and carry the standard footer.

---

For any question not answered here — letterhead, recital patterns, defined-term capitalization, date-format conventions, classification defaults, or the definitive scope of the Winston Legacy Exception — refer to the Style Guide, A50 (Control No. GOV-2022-050). A50 is the controlling authority; this reference is a convenience summary of its numbering and footer sections.

*Document control point for this reference: Coopa Blue Health, Inc., Governance.*
